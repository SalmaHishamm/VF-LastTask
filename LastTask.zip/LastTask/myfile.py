
import cx_Oracle
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.utils import formataddr #3ashan yaban salma hisham msh el mail
from flask import Flask, redirect, render_template, request, jsonify, session, url_for
import requests
import jwt



    
#alarm count
alarm_count=3

#Database Connection
connection = cx_Oracle.connect('system/12345@localhost:1521/xe')
cursor=connection.cursor()

cursor.execute('SELECT COUNT(*) FROM students')
count = cursor.fetchone()[0]

print(count)

# Sender's email address and password
sender_email = "salmahesham60@gmail.com"
sender_name="Salma Hisham"
password = "rjnkzyokivtspvxt"

# Recipient's email address
recipient_email = ["salmahesham60@gmail.com"]

# Create the email message
subject = "The system status is in danger!"

text = 'Hello this mail sent from python'

html = """\
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Warning</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-color: #f8e1e1;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }
        .warning-container {
            background-color: #f44336;
            color: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
            text-align: center;
        }
        h1 {
            margin: 0;
            font-size: 30px;
        }
        p {
            font-size: 18px;
        }
    </style>
</head>
<body>
    <div class="warning-container">
        <h1>Warning!</h1>
       
        <p>The number of records has exceeded the limit</p>
    </div>
</body>
</html>
"""

msg = MIMEMultipart("alternative") #alternative de khalteny html file maykonsh attachment
#msg['From'] = sender_email
msg['From'] = formataddr((sender_name,sender_email))
msg['To'] = ', '.join(recipient_email)
msg['Subject'] = subject

part1=MIMEText(text, 'plain')
part2=MIMEText(html, 'html')

msg.attach(part1)
msg.attach(part2)




# Connect to the SMTP server and send the email
smtp_server = "smtp.gmail.com"  # Replace with your SMTP server address
smtp_port = 587  # Replace with your SMTP server port (usually 587 for TLS)


def Validate(name,password):
    #cursor.execute('SELECT * FROM Users where Username=%s and Password=%s' ,(name,password))
    cursor.execute('SELECT * FROM Users WHERE Username = :name AND Password = :password', {'name': name, 'password': password})

    #cursor.execute("INSERT INTO table VALUES (%s, %s, %s)", (var1, var2, var3))
    result = cursor.fetchall()
    print(result)
    RowsCount=len(result)
    if(RowsCount>0) :
      return True
    else :
       return False
    



    
 #API   
app = Flask(__name__ ,static_url_path='/css' , static_folder='css')
app.secret_key = 'mysecret'




@app.route('/api/hello', methods=['GET'])
def hello():
    return jsonify(message='Hello, World!')


@app.route('/api/add', methods=['POST'])
def add():
    data = request.get_json()
    if 'a' in data and 'b' in data:
        result = data['a'] + data['b']
        return jsonify(result=result)
    else:
        return jsonify(error='Invalid input')
    
    
@app.route('/api/send', methods=['GET'])
def send():
 data = request.get_json()

 if (count>=alarm_count ):
    
    try :
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.starttls()
            server.login(sender_email, password)
   
            server.sendmail(sender_email, data['email'], msg.as_string())
           

    except Exception as e:
        print(e)
    
 else :
   
    print("The status is safe")
        
        
 return jsonify(message='Hello, World!')







@app.route('/' , methods=['GET'])
def index():
    return render_template('login.html')

@app.route('/login', methods=['GET'])
def loadLogin():
    return render_template('login.html') 

@app.route('/login', methods=['POST'])
def login():
    
    username = request.form['username']
    password = request.form['password']

    
    if (Validate(username,password)==True):
        # Successful login, you can store user session information here
        #session['logged_in'] = True
        session['username'] = username
        return render_template('index.html')
    else:
        # Authentication failed, show an error message
        return render_template('login.html', alert_message='Invalid username or password')
    
    
@app.route('/index', methods=['GET'])
def loadIndex():
    if 'username' in session:
        return render_template('index.html')
    return render_template('login.html')

@app.route('/logout', methods=['GET'])
def logout():
    print(session)
    session.pop('username', None)
    print(session)
    return redirect(url_for('login'))

   
@app.route('/index', methods=['POST'])
def run_script():
    script_input = request.form['email']
    if (count>=alarm_count and len(script_input)>0):
    
     try :
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.starttls()
            server.login(sender_email, password)
   
            server.sendmail(sender_email, script_input, msg.as_string())
            # print(data['name'])
            # print(data)

     except Exception as e:
        print(e)
    
    else :
   
      print("The status is safe")
   
    return render_template('index.html')





if __name__ == '__main__':
    
    app.run(debug=True)
    
    
    




   
